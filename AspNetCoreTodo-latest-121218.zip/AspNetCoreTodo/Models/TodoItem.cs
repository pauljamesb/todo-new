using System;

namespace AspNetCoreTodo.Models
{
    public class TodoItem
    {
      public Guid Id { get; set; }
      public bool IsDone { get; set; }
      public string Title { get; set; }
      public string Desc { get; set; }
      public string Stars { get; set; }
      public string Rating { get; set; }
      public bool FamFriendly { get; set; }
      public string Genre { get; set; }
    }
}
