// Got to page 27

using System.Collections.Generic;

namespace AspNetCoreTodo.Models
{
    public class TodoViewModel
    {
        public IEnumerable<TodoItem> Items { get; set; }

        public IEnumerable<TodoItem2> Items2 { get; set; }


            
        public IEnumerable<TodoItem> CompItems { get; set; }


    }
}
