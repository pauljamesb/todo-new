﻿$(document).ready(function () {

    // Wire up all of the checkboxes to run markCompleted()
    $('.done-checkbox').on('click', function (e) {
        markCompleted(e.target);

        console.log(e);
    });
});

function markCompleted(checkbox) {
    checkbox.disabled = true;

    var row = checkbox.closest('div.lABasicList__RowItem');
    $(row).addClass('done');

    var form = checkbox.closest('form');
    form.submit();


    console.log("From markCompleted +++++++++++++++++++++++")
    console.log("Row:");
    console.log(row);
    console.log("Form:");
    console.log(form);

}