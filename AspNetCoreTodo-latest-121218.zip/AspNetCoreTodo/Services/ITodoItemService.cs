using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AspNetCoreTodo.Models;

namespace AspNetCoreTodo.Services
{
    public interface ITodoItemService
    {
        Task<TodoItem[]> GetIncompleteItemsAsync();

        Task<TodoItem2[]> GetIncompleteItemsAsync2();

        Task<bool> AddItemAsync(TodoItem newItem);

        Task<bool> AddItemAsync2(TodoItem2 newItem);





        Task<bool> MarkDoneAsync(Guid id);





        Task<TodoItem[]> GetCompleteItemsAsync();
    }
}
